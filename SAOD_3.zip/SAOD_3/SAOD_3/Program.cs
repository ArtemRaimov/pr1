﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAOD_3
{
    public class ListNode<T>
    {
        public T value;
        public ListNode<T> next;
        public ListNode(T value)
        {
            this.value = value;
        }
    }
    public class DListNode<T>
    {
        public T value;
        public DListNode<T> next, prev;
        public DListNode(T value)
        {
            this.value = value;
        }
    }
    public class LinkedList<T> : IEnumerator, IEnumerable
    {
        int Count;
        ListNode<T> first;
        ListNode<T> last;
        public int position;
        public LinkedList()
        {
            Count = 0;
            first = null;
            last = null;
            position = 0;
        }
        public T this[int index]
        {
            get
            {
                var res = this.first;
                int i = 0;
                while (i < Count && i < index)
                {
                    res = res.next;
                    i++;
                }
                return res.value;
            }
        }
        public void AddLast(T item)
        {
            if (Count == 0)
                AddFirst(item);
            else
            {
                var LItem = new ListNode<T>(item);
                this.last.next = LItem;
                this.last = LItem;
                Count++;
            }
        }
        public void AddFirst(T item)
        {
            var LItem = new ListNode<T>(item);
            LItem.next = this.first;
            this.first = LItem;
            if (Count == 0)
                this.last = LItem;
            Count++;
            currentItem = first;
        }
        public void Insert(int pos, T item)
        {
            var LItem = new ListNode<T>(item);
            if (pos == 0)
                AddFirst(item);
            else
            if (pos == Count)
                AddLast(item);
            else
            if (pos < Count)
            {
                ListNode<T> curItem = this.first;
                for (int i = 0; i < pos - 1; i++)
                {
                    if (i == Count)
                        break;
                    curItem = curItem.next;
                }
                if (pos < Count)
                    LItem.next = curItem.next;
                curItem.next = LItem;
                Count++;
            }
        }
        public void Remove(int pos)
        {
            if (pos == 0)
            {
                this.first = first.next;
                Current = first;
                Count--;
            }
            else
            if (pos < Count)
            {
                ListNode<T> curItem = this.first;
                for (int i = 0; i < pos - 1; i++)
                {
                    if (i == Count)
                        break;
                    curItem = curItem.next;
                }
                if (pos == Count - 1)
                {
                    this.last = curItem;
                    last.next = null;
                }
                else
                {
                    curItem.next = curItem.next.next;
                }
                Count--;
            }
        }
        public ListNode<T> Last()
        {
            return this.last;
        }
        public ListNode<T> First()
        {
            return this.first;
        }
        public void Clear()
        {
            this.first = this.last = null;
            Count = 0;
        }
        public int Size()
        {
            return Count;
        }
        public int IndexOf(T item)
        {
            var curItem = first;
            int i = 0;
            while (i < Count)
            {
                if (curItem.value.Equals(item))
                    return i;
                i++;
                curItem = curItem.next;
            }
            return -1;
        }

        ListNode<T> currentItem;
        public object Current
        {

            get { return currentItem; }
            set { currentItem = value as ListNode<T>; }
        }
        public bool MoveNext()
        {
            if (position > 0 && position < Count)
            {
                Current = currentItem.next;
            }
            position++;
            return (position <= Count);
        }

        public void Reset()
        {
            currentItem = first;
            position = 0;
        }

        public IEnumerator GetEnumerator()
        {
            Reset();
            return (IEnumerator)this;
        }
    }


    class DLinkedList<T> : IEnumerator, IEnumerable
    {
        int position, Count;
        public DListNode<T> first, last, currentItem = null;

        public DLinkedList()
        {
            Count = position = 0;
            first = last = null;
        }
        public T this[int index]
        {
            get
            {
                DListNode<T> result = null;
                if (index <= Count)
                {
                    if (index < (int)(Count / 2))
                    {
                        var res = this.first;
                        int i = 0;
                        while (i < Count && i < index)
                        {
                            res = res.next;
                            i++;
                        }
                        return res.value;
                    }
                    else
                    {
                        var res = this.last;
                        int i = Count;
                        while (i > 0 && i > index + 1)
                        {
                            res = res.prev;
                            i--;
                        }
                        return res.value;
                    }
                }
                return result.value;
            }
        }
        public void AddLast(T item)
        {
            var LItem = new DListNode<T>(item);
            if (Count == 0)
            {
                AddFirst(item);
            }
            else
            {
                LItem.prev = last;
                LItem.next = first;
                last.next = LItem;
                first.prev = LItem;
                last = LItem;
                Count++;
            }
        }
        public void AddFirst(T item)
        {
            var LItem = new DListNode<T>(item);
            if (Count == 0)
            {
                first = last = LItem;
                last.prev = first;
                first.next = last;
            }
            else
            {
                LItem.next = first;
                LItem.prev = last;
                first.prev = LItem;
                last.next = LItem;
                first = LItem;
            }
            currentItem = first;
            Count++;
        }
        public void Insert(int pos, T item)
        {
            if (pos <= Count && pos > -1)
            {
                var LItem = new DListNode<T>(item);
                if (pos == 0)
                    AddFirst(item);
                else if (pos == Count)
                    AddLast(item);
                else
                {
                    if (pos <= (int)Count / 2)
                    {
                        var res = this.first;
                        int i = 0;
                        while (i < Count && i < pos - 1)
                        {
                            res = res.next;
                            i++;
                        }
                        res.next.prev = LItem;
                        LItem.next = res.next;
                        LItem.prev = res;
                        res.next = LItem;
                    }
                    else
                    {
                        var res = this.last;
                        int i = Count - 1;
                        while (i > 0 && i >= pos)
                        {
                            res = res.prev;
                            i--;
                        }
                        res.next.prev = LItem;
                        LItem.next = res.next;
                        LItem.prev = res;
                        res.next = LItem;
                    }
                    Count++;
                }

            }
        }
        public void Remove(int pos)
        {
            if (pos <= Count && pos > -1)
            {
                if (pos < (int)Count / 2)
                {
                    var res = first;
                    int i = 0;
                    while (i < Count && i < pos)
                    {
                        res = res.next;
                        i++;
                    }
                    res.prev.next = res.next;
                    res.next.prev = res.prev;
                    if (pos == 0)
                        first = res.next;
                }
                else
                {
                    var res = last;
                    int i = Count - 1;
                    while (i > 0 && i > pos)
                    {
                        res = res.prev;
                        i--;
                    }
                    res.next.prev = res.prev;
                    res.prev.next = res.next;
                    if (pos == Count - 1)
                        last = res.prev;
                }
                Count--;
            }
        }
        public T Last()
        {
            return last.value;
        }
        public T First()
        {
            return first.value;
        }
        public void Clear()
        {
            first = last = null;
        }
        public int IndexOf(T value)
        {
            int index = 0;
            foreach (DListNode<T> i in this)
            {
                if (i.value.Equals(value))
                    return index;
                index++;
            }
            return -1;
        }
        public int Size()
        {
            return Count;
        }
        public object Current
        {

            get { return currentItem; }
            set { currentItem = value as DListNode<T>; }
        }
        public bool MoveNext()
        {
            if (position > 0 && position <= Count)
                Current = currentItem.next;
            position++;
            return (position <= Count);
        }

        public void Reset()
        {
            position = 0;
            currentItem = first;
        }

        public IEnumerator GetEnumerator()
        {
            Reset();
            return (IEnumerator)this;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Односвязный");
            var lst = new LinkedList<int>();
            lst.AddFirst(1);
            lst.AddLast(2);
            lst.AddLast(3);
            lst.Insert(0, 0);
            lst.Remove(0);
            for (int i = 0; i < lst.Size(); i++)
                Console.WriteLine(lst[i]);
            Console.WriteLine(lst.IndexOf(1));
            foreach (ListNode<int> i in lst)
                Console.Write(i.value.ToString() + ' ');
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Двусвязный");
            var dlst = new DLinkedList<int>();
            dlst.AddLast(1);
            dlst.AddLast(2);
            dlst.AddLast(3);
            dlst.AddLast(4);
            dlst.AddLast(5);
            dlst.AddLast(6);
            dlst.AddLast(7);
            dlst.AddLast(8);
            dlst.Remove(6);
            for (int i = 0; i < dlst.Size(); i++)
                Console.WriteLine(dlst[i]);
            foreach (DListNode<int> i in dlst)
                Console.Write(i.value.ToString() + ' ');
            Console.WriteLine();
            Console.WriteLine(dlst.IndexOf(1));
            Console.ReadLine();
        }
    }
}

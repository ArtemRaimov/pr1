﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace saod3
{
    class List<T> : IEnumerator, IEnumerable
    {
        private T[] array;
        private int size;
        private int index = -1;
        public List()
        {
            array = new T[size];
        }
        public List(int s)
        {
            array = new T[s];
            size = s;
        }
        public IEnumerator GetEnumerator()
        {
            return (IEnumerator)this;
        }
        public bool MoveNext()
        {
            index++;
            return (index < array.Length);
        }
        public void Reset()
        {
            index = -1;
        }
        public object Current
        {
            get { return array[index]; }
        }
        public void Add(T t)
        {
            Array.Resize(ref array, size + 1);
            array[size] = t;
            size++;
        }
        public T First()
        {
            return array[0];
        }
        public T Last()
        {
            return array[size - 1];
        }
        public void Clear()
        {
            size = 0;
            array = new T[size];
        }
        public int Count
        {
            get
            {
                return size;
            }
        }
        public T this[int index]
        {
            get
            {
                return array[index];
            }
            set
            {
                array[index] = value;
            }
        }
        public void Insert(int ind, T t)
        {
            if (size >= ind)
            {
                Array.Resize(ref array, size + 1);
                for (int i = size; i > ind; i--)
                {
                    array[i] = array[i - 1];
                }
                size++;
                array[ind] = t;
            }
        }
        public void RemoveAt(int ind)
        {
            if (size >= ind)
            {
                for (int i = ind; i < size - 1; i++)
                {
                    array[i] = array[i + 1];
                }
                Array.Resize(ref array, size - 1);
                size--;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace saod3
{
    class Stack<T>
    {
        private T[] array;
        private int size;
        public Stack()
        {
            array = new T[size];
        }
        public void Push(T t)
        {
            Array.Resize(ref array, size + 1);
            array[size] = t;
            size++;
        }
        public void Pop()
        {
            if (size != 0)
            {
                Array.Resize(ref array, size - 1);
                size--;
            }
        }
        public bool Empty()
        {
            return size == 0;
        }
        public T Peek()
        {
            return array[size - 1];
        }
        public int Size()
        {
            return size;
        }
    }
}

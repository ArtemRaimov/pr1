﻿using System;

namespace saod1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 1;
            int k = 0;
            int[,] array = new int[10, 10];
            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (a == r.Next(0, 3))
                    {
                        array[i, j] = 1;
                        k++;
                    }
                    else
                    {
                        array[i, j] = 0;
                    }
                    //array[i, j] = r.Next();
                    //Console.WriteLine(array[i,j]);
                }
            }
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Console.Write(" " + array[i, j] + " ");
                }
                Console.WriteLine("");
            }
            void fill(int x,int y, int w, int h, int [,] a)
            {
                if (x>=0 && y>=0 && x<10 && y<10 && a[x,y]==h)
                {
                    a[x, y] = h;
                    fill(x+1, y, w, h, a);
                    fill(x, y+1, w, h, a);
                    fill(x, y-1, w, h, a);
                    fill(x-1, y, w, h, a);
                }
            }
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace saod3
{
    class Program
        {
        static void Main(string[] args)
        {
            void Rec()
            {
                int p = 1;
                int k0 = 0;
                int k1 = 0;
                int k2 = 0;
                Random r = new Random();
                Stack<KeyValuePair<int, int>> stack = new Stack<KeyValuePair<int, int>>();
                Console.WriteLine("Введите размер матрицы");
                int a = Convert.ToInt32(Console.ReadLine());
                int[,] mat = new int[a, a];
                void fill(int x, int y, int c, int d, int[,] m)
                {
                    if (x >= 0 && y >= 0 && x < a && y < a && m[x, y] == d)
                    {
                        m[x, y] = c;
                        fill(x + 1, y, c, d, m);
                        fill(x, y + 1, c, d, m);
                        fill(x - 1, y, c, d, m);
                        fill(x, y - 1, c, d, m);
                    }
                }
                void fill2(KeyValuePair<int, int> coor)
                {
                    stack.Push(coor);
                    while (!stack.Empty())
                    {
                        var key0 = stack.Peek();
                        stack.Pop();
                        if (mat[key0.Key, key0.Value] == 0)
                        {
                            mat[key0.Key, key0.Value] = 2;
                            if (key0.Key + 1 < a && mat[key0.Key + 1, key0.Value] == 0)
                            {
                                coor = new KeyValuePair<int, int>(key0.Key + 1, key0.Value);
                                stack.Push(coor);
                            }
                            if (key0.Value + 1 < a && mat[key0.Key, key0.Value + 1] == 0)
                            {
                                coor = new KeyValuePair<int, int>(key0.Key, key0.Value + 1);
                                stack.Push(coor);
                            }
                            if (key0.Value - 1 >= 0 && mat[key0.Key, key0.Value - 1] == 0)
                            {
                                coor = new KeyValuePair<int, int>(key0.Key, key0.Value - 1);
                                stack.Push(coor);
                            }
                            if (key0.Key - 1 >= 0 && mat[key0.Key - 1, key0.Value] == 0)
                            {
                                coor = new KeyValuePair<int, int>(key0.Key - 1, key0.Value);
                                stack.Push(coor);
                            }
                        }
                    }
                }
                void writing(int[,] m)
                {
                    for (int i = 0; i < a; i++)
                    {
                        for (int j = 0; j < a; j++)
                        {
                            Console.Write(" " + m[i, j] + " ");
                        }
                        Console.WriteLine("");
                    }
                }
                for (int i = 0; i < a; i++)
                {
                    for (int j = 0; j < a; j++)
                    {
                        if (p == r.Next(0, 3))
                        {
                            mat[i, j] = p;
                            k1++;
                        }
                        else
                        {
                            mat[i, j] = 0;
                        }
                    }
                }
                writing(mat);
                Console.WriteLine("Введите х");
                int x1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите y");
                int y1 = Convert.ToInt32(Console.ReadLine());
                var key = new KeyValuePair<int, int>(x1, y1);
                fill2(key);
                writing(mat);
                for (int i = 0; i < a; i++)
                {
                    for (int j = 0; j < a; j++)
                    {
                        if (mat[i, j] == 0)
                        {
                            k0++;
                        }
                        else if (mat[i, j] == 2)
                        {
                            k2++;
                        }
                    }
                }
                Console.WriteLine("Количество нулей " + k0);
                Console.WriteLine("Количество единиц " + k1);
                Console.WriteLine("Количество двоек " + k2);
                Console.ReadLine();
            }
            int num = 0;
            List<int> mylist = new List<int>();
            Console.WriteLine("Метод Add, добовляется 1, 2, 3, 4");
            for (int i = 1; i < 5; i++)
            {
                num++;
                mylist.Add(num);
            }
            num = 0;
            Console.ReadLine();
            Console.WriteLine("Foreach");
            foreach (int element in mylist)
            {
                Console.WriteLine("Номер " + num + " Элемент " + element);
                num++;
            }
            Console.ReadLine();
            Console.WriteLine("Метод First " + mylist.First());
            Console.WriteLine("Метод Last " + mylist.Last());
            Console.WriteLine("Count " + mylist.Count);
            Console.WriteLine("this[1] = " + mylist[1]);
            mylist[1] = 12;
            Console.WriteLine("Изменено на 12 this[1] =  " + mylist[1]);
        }
    }
}

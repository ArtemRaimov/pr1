﻿using System;
using System.Collections;

namespace SAOD_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Vect<int> a = new Vect<int>();
            a.Add(1);
            a.Add(2);
            a.Add(3);
            a.Add(4);
            Predicate<int> isPositive = delegate (int x) { return x > 2; };
            Console.WriteLine(a.FindIndex(isPositive));
        }
    }
}
public class Vect<T>
{
    public int size;
    public int maxsize;
    T[] mas;
    public Vect()
    {
        size = 0;
        maxsize = 1;
        mas = new T[size];
    }
    public void Add(T item)
    {
        size++;
        if (size == maxsize)
            Resize();
        mas[size - 1] = item;
    }
    void Resize()
    {
        maxsize *= 2;
        Array.Resize(ref mas, maxsize);
    }
    public void Insert(T item, int pos)
    {
        if (size == maxsize)
            Resize();
        T[] newMas = new T[size];
        for (int i = 0; i <= pos; i++)
            newMas[i] = mas[i];
        newMas[pos] = item;
        for (int i = pos; i < size - 1; i++)
            newMas[i + 1] = mas[i];
        mas = newMas;
    }
    public void RemoveAt(int pos)
    {
        T[] newMas = new T[size - 1];
        for (int i = 0; i < pos; i++)
            newMas[i] = mas[i];
        for (int i = pos; i < size - 1; i++)
            newMas[i] = mas[i + 1];
        mas = newMas;
    }
    public T Last()
    {
        return mas[size - 1];
    }
    public T First()
    {
        return mas[0];
    }
    public void Clear()
    {
        Array.Resize(ref mas, 0);
        size = 0;
        maxsize = 1;
    }
    public int Count { get { return size; } }
    public T this[int index] { get { return mas[index]; } set { } }
    public override string ToString()
    {
        string s = "";
        for (int i = 0; i < mas.Length; i++)
            s += mas[i].ToString() + " ";
        return s;
    }


    private class MyEnumerator : IEnumerator
    {
        public T[] items;
        int position = -1;

        public MyEnumerator(T[] list)
        {
            items = list;
        }
        private IEnumerator getEnumerator()
        {
            return (IEnumerator)this;
        }
        public bool MoveNext()
        {
            position++;
            return (position < items.Length);
        }
        public void Reset()
        {
            position = -1;
        }
        public object Current
        {
            get
            {
                try
                {
                    return items[position];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new InvalidOperationException();
                }
            }
        }
    }
    public IEnumerator GetEnumerator()
    {
        return new MyEnumerator(mas);
    }

    public bool Contains(T item)
    {
        bool check = false;
        foreach (T i in this)
            if (i.Equals(item))
            {
                check = true;
                break;
            }

        return check;
    }

    public int IndexOf(T item)
    {
        int pos = 0;
        foreach (T i in this)
            if (i.Equals(item))
                break;
            else
                pos++;
        return pos;
    }

    public void ForEach(Action<T> action)
    {
        foreach (T i in this)
        {
            action(i);
        }
    }

    public T Find(Predicate<T> match)
    {
        foreach (T i in this)
        {

            if (match(i))
            {
                return i;
            }
        }
        return this[0];
    }
    public int FindIndex(Predicate<T> match)
    {
        int pos = 0;
        foreach (T i in this)
        {
            if (match(i))
            {
                break;
            }
            pos++;
        }
        return pos;
    }
}

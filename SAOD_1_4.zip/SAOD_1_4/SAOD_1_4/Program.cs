﻿using System;
using System.Collections.Generic;

namespace SAOD_1_4
{
    class Program
    {
        class Point
        {
            public int x;
            public int y;
            public Point(int a, int b)
            {
                x = a;
                y = b;
            }
        }
        static void Main(string[] args)
        {
            Stack<int> mystack1 = new Stack<int>();
            DynStack<int> mystack2 = new DynStack<int>();
            Stack3<int> mystack3 = new Stack3<int>();
            ListStack<int> mystack4 = new ListStack<int>();
            System.Diagnostics.Stopwatch watch;
            long elapsedMs;

            //int N = 10000;

            //var stack = new System.Collections.Generic.Stack<int>();
            //watch = System.Diagnostics.Stopwatch.StartNew();

            //for (int i = 0; i != N; i++)
            //{
            //    stack.Push(i);
            //}
            //for (int i = 0; i != N; i++)
            //{
            //    stack.Pop();
            //}

            //watch.Stop();
            //elapsedMs = watch.ElapsedMilliseconds;
            //System.Console.WriteLine("0)" + elapsedMs.ToString());
            //watch = System.Diagnostics.Stopwatch.StartNew();

            //for (int i = 0; i != N; i++)
            //{
            //    mystack1.Push(i);
            //}
            //for (int i = 0; i != N; i++)
            //{
            //    mystack1.Pop();
            //}

            //watch.Stop();
            //elapsedMs = watch.ElapsedMilliseconds;
            //System.Console.WriteLine("1)" + elapsedMs.ToString());
            //watch = System.Diagnostics.Stopwatch.StartNew();

            //for (int i = 0; i != N; i++)
            //{
            //    mystack2.Push(i);
            //}
            //for (int i = 0; i != N; i++)
            //{
            //    mystack2.Pop();
            //}

            //watch.Stop();
            //elapsedMs = watch.ElapsedMilliseconds;
            //System.Console.WriteLine("2)" + elapsedMs.ToString());
            //watch = System.Diagnostics.Stopwatch.StartNew();

            //for (int i = 0; i != N; i++)
            //{
            //    mystack3.Push(i);
            //}
            //for (int i = 0; i != N; i++)
            //{
            //    mystack3.Pop();
            //}

            //watch.Stop();
            //elapsedMs = watch.ElapsedMilliseconds;
            //System.Console.WriteLine("3)" + elapsedMs.ToString());
            //watch = System.Diagnostics.Stopwatch.StartNew();

            //for (int i = 0; i != N; i++)
            //{
            //    mystack4.Push(i);
            //}
            //for (int i = 0; i != N; i++)
            //{
            //    mystack4.Pop();
            //}
            //watch.Stop();
            //elapsedMs = watch.ElapsedMilliseconds;
            //System.Console.WriteLine("4)" + elapsedMs.ToString());
            //Console.WriteLine(mystack.Size());
            //Console.WriteLine(mystack.Peek());

            //mystack.Push("first");
            //mystack.Push("second");

            //Console.WriteLine(mystack.Empty());
            //Console.WriteLine(mystack.Size());

            //mystack.Push("third");
            //mystack.Push("fourth");

            //while (!mystack.Empty())
            //{
            //    Console.WriteLine(mystack.Peek());
            //    mystack.Pop();
            //}

            //mystack.Pop();
            //Console.WriteLine(mystack.Empty());

            //Калькулятор
            //while (true)
            //{
            //    string a = Console.ReadLine();
            //    int d = (MyClass.evaluate(a));
            //    Console.WriteLine(d);
            //    Console.ReadLine();
            //    Console.Clear();
            //}

            //Заливка матрицы
            int n = 10;
            int[,] mas = new int[n, n];
            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    mas[i, j] = r.Next(0, 2);
                    Console.Write(mas[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();

            Stack<Point> point = new Stack<Point>();

            void fill(Point p, int[,] m)
            {
                if (m[p.x, p.y] == 0)
                {
                    m[p.x, p.y] = 2;
                    if (p.x - 1 > 0)
                        fill(new Point(p.x - 1, p.y), m);
                    if (p.x + 1 < m.GetLength(0))
                        fill(new Point(p.x + 1, p.y), m);
                    if (p.y + 1 < m.GetLength(0))
                        fill(new Point(p.x, p.y + 1), m);
                    if (p.y - 1 > 0)
                        fill(new Point(p.x, p.y - 1), m);
                }
            }
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (mas[i, j] == 0)
                    {
                        fill(new Point(i, j), mas);
                    }
                }
            }
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Console.Write(mas[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }
    public class Stack<T>
    {
        int size;
        public T[] elements;
        int current;
        public Stack()
        {
            size = 10;
            elements = new T[size];
            current = -1;
        }
        public void Push(T s)
        {
            if (current != size - 1)
            {
                current++;
                elements[current] = s;
            }
        }
        public void Pop()
        {

            if (current != -1)
                current--;
        }
        public string Peek()
        {
            if (current != -1)
                return elements[current].ToString();
            else
                return "Стек пуст";
        }
        public bool Empty()
        {
            if (current == -1)
                return true;
            else
                return false;
        }
        public int Size()
        {
            return (current + 1);
        }
    }
    public class DynStack<T>
    {
        public T[] elements;
        int current;

        public DynStack()
        {
            elements = new T[0];
            current = 0;
        }
        public void Push(T s)
        {
            current++;
            Array.Resize(ref elements, current);
            elements[current - 1] = s;
        }
        public void Pop()
        {

            if (current != 0)
                current--;
        }
        public string Peek()
        {
            if (current != 0)
                return elements[current - 1].ToString();
            else
                return "Стек пуст";
        }
        public bool Empty()
        {
            if (current == 0)
                return true;
            else
                return false;
        }
        public int Size()
        {
            return (current);
        }
    }
    public class Stack3<T>
    {
        public T[] elements;
        int current;
        public Stack3()
        {
            elements = new T[0];
            current = 0;
        }
        public void Push(T s)
        {
            current++;
            T[] newMas = new T[current];
            for (int i = 0; i < current - 1; i++)
            {
                newMas[i] = elements[i];
            }
            newMas[current - 1] = s;
            elements = newMas;
        }
        public void Pop()
        {
            current--;
            T[] newMas = new T[current];
            for (int i = 0; i < current; i++)
            {
                newMas[i] = elements[i];
            }
            elements = newMas;
        }
        public string Peek()
        {
            if (current != 0)
                return elements[current - 1].ToString();
            else
                return "Стек пуст";
        }
        public bool Empty()
        {
            if (current == 0)
                return true;
            else
                return false;
        }
        public int Size()
        {
            return (current);
        }
    }
    public class ListStack<T>
    {
        public List<T> elements;
        public int size;
        public ListStack()
        {
            elements = new List<T>();
            size = 0;
        }
        public void Push(T s)
        {
            size++;
            elements.Add(s);
        }
        public void Pop()
        {
            if (size != 0)
            {
                elements.RemoveAt(size - 1);
                size--;
            }
        }
        public T Peek()
        {
            T x = elements[size - 1];
            return x;
        }
        public bool Empty()
        {
            if (size == 0)
                return true;
            else
                return false;
        }
        public int Size()
        {
            return (size);
        }
    }
    public static class MyClass
    {
        public static int evaluate(string str)
        {
            ListStack<int> values = new ListStack<int>();
            ListStack<char> ops = new ListStack<char>();
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == ' ') continue; 
                if (str[i] >= '0' && str[i] <= '9')
                {
                    int number = Convert.ToInt32(str[i] - 48);
                    
                    values.Push(number);
                    
                }
                else if (str[i] == '(')
                    ops.Push(str[i]);  
                else if (str[i] == ')')
                { 
                    while (ops.Peek() != '(')
                    {
                        int a = (int)values.Peek();
                        values.Pop();
                        int b = (int)values.Peek();
                        values.Pop();
                        int res = execOP(ops.Peek(), a, b);
                        ops.Pop();
                        values.Push(res);
                    }
                    ops.Pop();
                }
                else if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/' || str[i] == '^')
                {
                    while (ops.size != 0 && priority(str[i], ops.Peek()))
                    {
                        int a = (int)values.Peek();
                        values.Pop();
                        int b = (int)values.Peek();
                        values.Pop();
                        int res = execOP(ops.Peek(), a, b);
                        ops.Pop();
                        values.Push(res); 
                    }
                    ops.Push(str[i]); 
                }
            }
            while (ops.size != 0)
            {
                int a = (int)values.Peek();
                values.Pop();
                int b = (int)values.Peek();
                values.Pop();
                int res = execOP(ops.Peek(), a, b);
                ops.Pop();
                values.Push(res);
            }
            return (int)values.Peek();
        }
        public static int execOP(char op, int a, int b)
        {
            switch (op)
            {
                case '-':
                    return (int)b - (int)a;
                case '+':
                    return (int)a + (int)b;
                case '*':
                    return (int)a * (int)b;
                case '^':
                    return (int)Math.Pow((int)b, (int)a);
                case '/':
                    return (int)b / (int)a;
            }
            return 'a';
        }
        public static bool priority(char op1, char op2)
        {
            if (op2 == '(' || op2 == ')')
                return false;
            if (op1 == '^')
                return false;
            if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
                return false;
            else
                return true;
        }
    }
}
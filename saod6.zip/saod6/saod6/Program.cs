﻿using System;

namespace saod6
{
    class Program
    {
        static void Main(string[] args)
        {
             Console.Write("Введите выражение: ");
             Console.WriteLine(Calc.Calculate(Console.ReadLine()));
        }
    }
}
